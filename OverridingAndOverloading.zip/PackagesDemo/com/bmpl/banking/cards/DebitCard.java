package PackagesDemo.com.bmpl.banking.cards;

import PackagesDemo.com.bmpl.banking.customers.Customers;
// Customers Class is imported because it's in different package

// public class DebitCard {
//     void applyForCard() {
//         Customers obj = new Customers();
//         System.out.println(obj.name);
//         System.out.println(obj.email);
//         System.out.println(obj.acc_no);
//     }
// }

// we can access the protected members of a class that is inside some
// other package using inheritance...
public class DebitCard extends Customers{
    void applyForCard() {
        System.out.println(name);
        System.out.println(email);
        System.out.println(acc_no);
    }
}
