package PackagesDemo.com.bmpl.banking.loan;

public class EduLoan {
    
}
