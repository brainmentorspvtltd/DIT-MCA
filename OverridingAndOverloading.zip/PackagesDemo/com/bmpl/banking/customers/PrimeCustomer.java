package PackagesDemo.com.bmpl.banking.customers;

// we don't have to import Customers class
// because it's in same package
// public class PrimeCustomer extends Customers {
    
// }

public class PrimeCustomer{
    void showCustomer() {
        Customers obj = new Customers();
        // obj.showCustomer();
        System.out.println(obj.acc_no);
        System.out.println(obj.email);
        // System.out.println(obj.balance);    // cannot access balance
        System.out.println(obj.phone);
    }
}
