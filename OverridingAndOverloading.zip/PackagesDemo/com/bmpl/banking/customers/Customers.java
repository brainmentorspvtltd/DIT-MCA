package PackagesDemo.com.bmpl.banking.customers;

public class Customers {
    protected int acc_no;
    public String name;
    public String email;
    private double balance; // will be accessible only in this class
    int phone;  // default, can't access phone outside this package

    void showCustomer() {
        System.out.println("Showing Customer Details...");
    }
}
