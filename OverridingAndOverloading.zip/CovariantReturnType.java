class A {
    int x = 12;
}

class APlus extends A {
    int x,y,z;
}

class Parent_2 {
    A show() {
        System.out.println("Parent Class Show...");
        A obj = new A();
        return obj;
    }

    int add() {
        System.out.println("Addition of two numbers...");
        return 10;
    }

}

class Child_2 extends Parent_2 {

    @Override
    int add() {
        return 144;
    }

    @Override
    APlus show() {
        System.out.println("Parent Class Show...");
        APlus obj = new APlus();
        return obj;
    }
}

public class CovariantReturnType {
    
}
