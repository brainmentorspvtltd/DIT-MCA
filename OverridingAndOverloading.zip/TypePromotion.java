public class TypePromotion {

    void show(byte x) {
        System.out.println("Byte X...");
    }

    void show(short x) {
        System.out.println("Short X...");
    }

    // void show(int x) {
    //     System.out.println("Int X...");
    // }

    // void show(long x) {
    //     System.out.println("Long X...");
    // }

    // void show(float x) {
    //     System.out.println("Float X...");
    // }

    // void show(double x) {
    //     System.out.println("Double X...");
    // }

    // void show(Integer x) {
    //     System.out.println("Integer X...");
    // }

    // void show(Float x) {
    //     System.out.println("Float X...");
    // }

    void show(int ...x) {
        System.out.println("Variable Length X...");
    }

    public static void main(String[] args) {
        TypePromotion obj = new TypePromotion();

        // JRE will give first chance to int
        // if int is not available then it will give chance to long
        // if long is not available then it will give chance to float
        // if float is not available then it will give chance to double
        // if double is not available then it will give chance to wrapper class of same type
        // if wrapper classes are not available then it will give chance to var args
        obj.show(12);
        obj.show(12,14,16);
        obj.show(12,18,12,4,6);
        obj.show(12,1);

        // to call byte and short we need to perform type casting...
        obj.show((byte)12);
        obj.show((short)12);
    }
}
