@interface IsLogin {
    int func();
}

class Parent {
    @IsLogin(func=20)
    protected void show() {
        System.out.println("Parent Show Method Called...");
    }
    void disp(String name) {
        System.out.println("Hello " + name);
    }
}

class Child extends Parent {
    @Override
    protected void show() {
        System.out.println("Child Show Method Called...");
    }

    
    void disp(String name, int age) {
        System.out.println("Hello " + name);
    }

}


public class OverridingRules {
    
}
