import java.util.Date;
import java.util.Scanner;

class Message {
    private String message;
    private Date date;
    private String userId;

    public String getMessage() {
        return this.message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Date getDate() {
        return this.date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getUserId() {
        return this.userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}

class User {
    private String userId;
    private String name;
    private String pwd;
    private int age;
    private String city;

    public String getUserId() {
        return this.userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPwd() {
        return this.pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public int getAge() {
        return this.age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getCity() {
        return this.city;
    }

    public void setCity(String city) {
        this.city = city;
    }

}

class View {
    void loginUser() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter User ID : ");
        String id = scanner.next();

        System.out.println("Enter User Name : ");
        String name = scanner.next();

        System.out.println("Enter User Password : ");
        String pwd = scanner.next();

        System.out.println("Enter User Age : ");
        int age = scanner.nextInt();

        System.out.println("Enter User City : ");
        String city = scanner.next();

        User user = new User();
        user.setUserId(id);
        user.setName(name);
        user.setPwd(pwd);
        user.setAge(age);
        user.setCity(city);

        DB obj = new DB();
        // String msg = obj.checkLogin(id, pwd);
        // Message msg = obj.checkLogin(id, pwd);

        Message msg = obj.checkLogin(user);
        System.out.println(msg);

        scanner.close();
    }
}

class DB {
    // String checkLogin(String userId, String pwd) {
    //     String message = "";
    //     Date date = new Date();
    //     if(userId.equals("Ram") &&  pwd.equals("1234")) {
    //         message = "Login Success...";
    //     }
    //     else {
    //         message = "Login Failed...";
    //     }
    //     return message;
    // }

    Message checkLogin(User user) {
        String message = "";
        Message msg = new Message();
        Date date = new Date();
        if(user.getUserId().equals("Ram") &&  user.getPwd().equals("1234")) {
            message = "Login Success...";
        }
        else {
            message = "Login Failed...";
        }
        msg.setMessage(message);
        msg.setDate(date);
        msg.setUserId(user.getUserId());
        return msg;
    }

}

public class PassObjectReturnObject {
    public static void main(String[] args) {
        View view = new View();
        view.loginUser();
    }
}
