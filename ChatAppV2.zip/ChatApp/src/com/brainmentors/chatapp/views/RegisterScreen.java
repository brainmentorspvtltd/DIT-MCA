package com.brainmentors.chatapp.views;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.brainmentors.chatapp.dao.UserDAO;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class RegisterScreen extends JFrame {

	private JPanel contentPane;
	private JTextField useridtxt;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegisterScreen frame = new RegisterScreen();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	private void register() {
		String userid = useridtxt.getText(); // Getting Text Value and Store in a Variable
		char[] password = passwordField.getPassword();
		System.out.println(userid + " "+password);
		UserDAO userDAO  = UserDAO.getInstance();
		try {
			String message = userDAO.register(userid, password);
			JOptionPane.showMessageDialog(this, message);
		} catch (ClassNotFoundException e) {
			JOptionPane.showMessageDialog(this, "Some Problem in Register");
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(this, "Some Problem in Register");
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		
	}

	/**
	 * Create the frame.
	 */
	public RegisterScreen() {
		setResizable(false);
		setTitle("Register");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 620, 419);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Register Form");
		lblNewLabel.setForeground(Color.MAGENTA);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 27));
		lblNewLabel.setBounds(251, 32, 235, 33);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Userid");
		lblNewLabel_1.setFont(new Font("Lucida Grande", Font.PLAIN, 23));
		lblNewLabel_1.setBounds(84, 134, 106, 33);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Password");
		lblNewLabel_1_1.setFont(new Font("Lucida Grande", Font.PLAIN, 23));
		lblNewLabel_1_1.setBounds(84, 210, 106, 33);
		contentPane.add(lblNewLabel_1_1);
		
		useridtxt = new JTextField();
		useridtxt.setFont(new Font("Lucida Grande", Font.PLAIN, 24));
		useridtxt.setBounds(234, 134, 311, 33);
		contentPane.add(useridtxt);
		useridtxt.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setFont(new Font("Lucida Grande", Font.PLAIN, 24));
		passwordField.setBounds(234, 217, 311, 40);
		contentPane.add(passwordField);
		
		JButton registerBt = new JButton("Register");
		registerBt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				register();
			}

			
		});
		registerBt.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		registerBt.setBounds(172, 298, 117, 29);
		contentPane.add(registerBt);
		
		JButton btnClearAll = new JButton("Clear All");
		btnClearAll.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		btnClearAll.setBounds(327, 299, 117, 29);
		contentPane.add(btnClearAll);
	}
}
