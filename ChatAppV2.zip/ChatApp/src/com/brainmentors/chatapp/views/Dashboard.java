package com.brainmentors.chatapp.views;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JMenuBar;
import javax.swing.JMenu;

public class Dashboard extends JFrame {
	
	public Dashboard() {
		setBounds(100, 100, 917, 573);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		setTitle("Chat App");
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(142, 144, 644, 382);
		lblNewLabel.setIcon(new ImageIcon(Dashboard.class.getResource("/assets/mad_blog_6012b5c838d421611838920.png")));
		getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Welcome to Chat Application");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel_1.setBounds(238, 40, 448, 57);
		getContentPane().add(lblNewLabel_1);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("Chat Options");
		menuBar.add(mnNewMenu);
		
		JMenu mnNewMenu_1 = new JMenu("Start Chat");
		mnNewMenu.add(mnNewMenu_1);
	}
}
