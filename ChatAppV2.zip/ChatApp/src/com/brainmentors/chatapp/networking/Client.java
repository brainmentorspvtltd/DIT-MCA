package com.brainmentors.chatapp.networking;

import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ResourceBundle;
import java.util.Scanner;

public class Client {
	Socket socket;
	private ResourceBundle rb = ResourceBundle.getBundle("config");
	public Client() throws UnknownHostException, IOException {
		int PORT = Integer.parseInt(rb.getString("PORTNO"));
		String IP = rb.getString("SERVER_IP");
		socket = new Socket(IP, PORT);
		System.out.println("Client Arrived...");
		System.out.println("Enter your message : ");
		Scanner scanner = new Scanner(System.in);
		String message = scanner.nextLine();
		OutputStream out = socket.getOutputStream();
		out.write(message.getBytes());
		System.out.println("Message Sent...");
		out.close();
		socket.close();
	}

	public static void main(String[] args) throws UnknownHostException, IOException {
		// TODO Auto-generated method stub
		Client client = new Client();
	}

}
