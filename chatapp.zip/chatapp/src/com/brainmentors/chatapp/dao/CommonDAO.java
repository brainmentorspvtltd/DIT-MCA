package com.brainmentors.chatapp.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;


// Transform Singleton class
public class CommonDAO {
	
	private ResourceBundle rb = ResourceBundle.getBundle("config");
	private Connection con ; // default null
	//private static CommonDAO commonDAO = new CommonDAO(); // Eager Object Creation
	private static CommonDAO commonDAO ; // null (Lazy Object Creation)
	private CommonDAO() {}
	// Eager Way
//	public static CommonDAO getInstance() {
//		return commonDAO;
//	}
	// Lazy Way
	public static CommonDAO getInstance() {
		if(commonDAO == null) {
			commonDAO = new CommonDAO();
		}
		return commonDAO;
	}
	public Connection createConnection() throws ClassNotFoundException, SQLException {
	
//		Step 1 - Load Driver
		Class.forName(rb.getString("DRIVER")); // Load a Driver Class (Low Level Communication)
//		Step 2 - Build Connection (Where is the DataBase)
//		final String CONNECTION_STRING = "jdbc:mysql://localhost:3306/chat_db";
		//final String CONNECTION_STRING = "jdbc:mysql://localhost:3306/chat_db";
		final String CONNECTION_STRING = rb.getString("DB_URL");
		// DB CRED
		final String USERID = rb.getString("DB_USERID");
		final String PASSWORD = rb.getString("DB_PASSWORD");
		if(con == null) {
		con = DriverManager.getConnection(CONNECTION_STRING, USERID, PASSWORD);
		}
		if(con != null) {
			System.out.println("Connection Created...");
			//con.close();
		}
		return con;
	}
	
//	public static void main(String[] args) throws ClassNotFoundException, SQLException {
//		CommonDAO obj = new CommonDAO();
//		obj.createConnection();
//	}

}
