package com.brainmentors.chatapp.dao;

import java.sql.Connection; // JDBC API
import java.sql.SQLException;
import java.sql.Statement;

// CRUD Operations
public class UserDAO {
	
	private static UserDAO userDAO = new UserDAO();
	
	public static UserDAO getInstance() {
		return userDAO;
	}
	
	CommonDAO commonDAO = CommonDAO.getInstance();
	public String  register(String userid, char[] password) throws ClassNotFoundException, SQLException{
		Connection con = null;
		Statement stmt = null ; // Query (Insert, Delete, Update, Read)
		// insert into chatusers (userid , password) values('amit','amit111')
		String SQL_QUERY = "insert into chatusers (userid , password) values('"+userid+"','"+new String(password)+"')";
		try {
		con = commonDAO.createConnection();
		stmt = con.createStatement();
		int record = stmt.executeUpdate(SQL_QUERY);
		if(record>0) {
			return "Register SuccessFully ";
		}
		else {
			return "Problem in Register ";
		}
		}
		finally {
			// this is block which always execute....
			// Resource Clean Up Code
			if(stmt!=null) {
				stmt.close();
			}
			if(con!=null) {
				con.close();
			}
		}
		
	
	}
	
	public void login() {
		
		
	}
	
	
//	public static void main(String[] args) throws ClassNotFoundException, SQLException {
//		UserDAO userDAO = UserDAO.getInstance();
//		System.out.println(userDAO.register("ravi", "r1111"));
//	}
	
//	public static void main(String[] args) {
		
//		CommonDAO commonDAO = CommonDAO.getInstance();
//		CommonDAO commonDAO2 = CommonDAO.getInstance();
//		CommonDAO commonDAO3 = CommonDAO.getInstance();
//		CommonDAO commonDAO4 = CommonDAO.getInstance();
//		if(commonDAO == commonDAO2 && commonDAO == commonDAO3 && commonDAO == commonDAO4) {
//			System.out.println("Same Ref");
//		}
//		else {
//			System.out.println("Not Same Ref");
//		}
//	}
}
