package com.brainmentors.chatapp.networking;

import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class Server {
	ServerSocket serverSocket;
	private ResourceBundle rb = ResourceBundle.getBundle("config");
	ArrayList<ServerWorker> workers = new ArrayList<ServerWorker>();
	public Server() throws IOException {
		int PORT = Integer.parseInt(rb.getString("PORTNO"));
		
		serverSocket = new ServerSocket(PORT);
		
		while(true) {
			System.out.println("Server Started...Waiting for client...");
			// Socket clientSocket = serverSocket.accept();\
			handleClient();
		}
	}
	
//	For multiple clients
	public void handleClient() throws IOException {
		while(true) {
			Socket clientSocket = serverSocket.accept();
			System.out.println("Client arrived...");
			// Thread Per Client
			ServerWorker serverWorker = new ServerWorker(clientSocket, this);
			workers.add(serverWorker);
			serverWorker.start();	
		}
	}
	
//	For Single Client
//	public Server() throws IOException {
//		int PORT = Integer.parseInt(rb.getString("PORTNO"));
//		serverSocket = new ServerSocket(PORT);
//		System.out.println("Server started...");
//		System.out.println("Waiting for client to connect...");
//		Socket socket = serverSocket.accept();	// handshaking with client...
//		System.out.println("Connected with client...");
//		InputStream in = socket.getInputStream();	// read bytes from network
//		byte arr[] = in.readAllBytes();
//		String str = new String(arr);
//		System.out.println("Message :: " + str);
//		in.close();
//		socket.close();
//	}
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Server server = new Server();
	}

}
