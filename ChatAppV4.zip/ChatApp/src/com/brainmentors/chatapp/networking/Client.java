package com.brainmentors.chatapp.networking;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ResourceBundle;
import java.util.Scanner;

import javax.swing.JTextArea;

public class Client {
	Socket socket;
	OutputStream out;
	InputStream in;
	ClientWorker worker;
	JTextArea textArea;
	private ResourceBundle rb = ResourceBundle.getBundle("config");
//	public Client() throws UnknownHostException, IOException {
//		int PORT = Integer.parseInt(rb.getString("PORTNO"));
//		String IP = rb.getString("SERVER_IP");
//		socket = new Socket(IP, PORT);
//		System.out.println("Client Arrived...");
//		System.out.println("Enter your message : ");
//		Scanner scanner = new Scanner(System.in);
//		String message = scanner.nextLine();
//		OutputStream out = socket.getOutputStream();
//		out.write(message.getBytes());
//		System.out.println("Message Sent...");
//		out.close();
//		socket.close();
//	}
	
	public Client(JTextArea textArea) throws UnknownHostException, IOException {
		int PORT = Integer.parseInt(rb.getString("PORTNO"));
		String IP = rb.getString("SERVER_IP");
		socket = new Socket(IP, PORT);
		out = socket.getOutputStream();
		in = socket.getInputStream();
		this.textArea = textArea;
		readMessage();
	}
	
	public void sendMessage(String message) throws IOException {
		// out.write(message.getBytes());
		out.write((message + "\n").getBytes());
		System.out.println("Message Sent..." + message);
	}
	
	public void readMessage() {
		//System.out.println("Reading Message...");
		worker = new ClientWorker(in, textArea);
		worker.start();
	}

//	public static void main(String[] args) throws UnknownHostException, IOException {
//		// TODO Auto-generated method stub
//		Client client = new Client();
//	}

}
