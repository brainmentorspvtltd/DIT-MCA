package com.brainmentors.chatapp.networking;

//Thread == Worker
//Worker has a job to complete

//public class ServerWorker implements Runnable {
public class ThreadDemo extends Thread{

	@Override
	public void run() {
		// Job to perform
		for(int i = 0; i < 5; i++) {
			System.out.println("Iteration is :: " + i + " " + Thread.currentThread());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public static void main(String[] args) {
		// Create thread
//		ServerWorker job = new ServerWorker();
//		job.start();
		// Assign job to thread
//		Thread worker = new Thread(job, "Worker Thread");
//		worker.start();  // Internally it will call run()
		
		ThreadDemo worker = new ThreadDemo();
		worker.start();
		
		for(int i = 0; i < 5; i++) {
			System.out.println("Main Iteration is :: " + i + " " + Thread.currentThread());
		}
	}

}
